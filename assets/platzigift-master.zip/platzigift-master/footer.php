<footer>
    <div class="container">
        <?php dynamic_sidebar('footer'); ?>
    </div>
</footer>

<?php wp_footer() ?>

</body>
</html>